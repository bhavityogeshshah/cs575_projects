Name: Bhavit Yogesh Shah
BNumber: B00979233
Email Id: bshah5@binghamton.edu

Language used: Java

Command to build the program


Run command for LCS
java Shah_BhavitY_pa3_lcs.java  "ABCB" "BDCA"

Run command for floyd
java Shah_BhavitY_pa3_floyd.java

References: 
printing lcs string: https://youtu.be/-zI4mrF2Pb4