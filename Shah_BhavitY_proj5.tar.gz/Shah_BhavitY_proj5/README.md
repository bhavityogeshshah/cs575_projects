Name: Bhavit Shah
B Number: B00979233
Email Id: bshah5@binghamton.edu

Language used: java

Build command : make
Run commad : 

```
java createkn01.java -k <filename>
```

```
java bruteforce.java -k <file_name>
```

```
java dynpro.java -k <file_name>
```

```
java backtrack.java -k <file_name>
```

# References
```
https://youtu.be/81vqsCxHWAw

https://youtu.be/GqOmJHQZivw

Chapter 13 Algorithm
```