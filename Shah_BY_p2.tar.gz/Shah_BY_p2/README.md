Name: Bhavit Yogesh Shah
BNumber: B0097933
Email Id: bshah5@binghamton.edu


Command to build:

javac program2.java

Command to run:

java program2.java

References: 

Matrix Rotation
https://medium.com/enjoy-algorithm/rotate-a-matrix-by-90-degrees-in-an-anticlockwise-direction-6326e80bb211
https://youtu.be/5kJ1SWu84-M
