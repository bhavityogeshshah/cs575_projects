Name: Bhavit Yogesh Shah
B Number: B00979233
Email :  bshah5@binghamton.edu

Command to build the program
javac assignment1.java

Command to run the program
java assignment1.java -m market_price.txt -p price_list.txt

Note: Please place the input file in the folder Shah_BhavitY_p1 folder along with the java file or provide the absolute path to the file. If any of the above steps are not followed then it would give an error.

References: 
https://youtu.be/b7AYbpM5YrE - Power set generation.